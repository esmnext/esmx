export declare const title: {
    home: string;
    about: string;
    notFound: string;
};

declare const _default: {
    packs: {
        enable: true;
    };
    devApp(esmx: import("@esmx/core").Esmx): Promise<import("@esmx/core").App>;
    server(esmx: import("@esmx/core").Esmx): Promise<void>;
    postBuild(esmx: import("@esmx/core").Esmx): Promise<void>;
    modules: {
        exports: string[];
    };
};
export default _default;

import { Page } from 'ssr-html/src/page';
export default class Home extends Page {
    state: {
        time: string;
    };
    title: string;
    render(): string;
    /**
     * 模拟服务端请求数据
     */
    onServer(): Promise<void>;
}

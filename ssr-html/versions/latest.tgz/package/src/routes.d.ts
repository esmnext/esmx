import './styles/global.css';
import type { Page } from './page';
export declare function getRoutePage(path: string): Promise<typeof Page>;

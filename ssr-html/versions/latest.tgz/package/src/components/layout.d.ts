import './layout.css';
interface LayoutOptions {
    url?: string;
    base?: string;
}
export declare function layout(slot: string, options?: LayoutOptions): string;
export {};

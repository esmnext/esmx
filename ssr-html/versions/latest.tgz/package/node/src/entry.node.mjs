(() => { // webpackBootstrap
"use strict";
var __webpack_modules__ = ({
454: (function (module) {
module.exports = import("@esmx/rspack").then(function(module) { return module; });

}),

});
/************************************************************************/
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

/************************************************************************/
// webpack/runtime/rspack_version
(() => {
__webpack_require__.rv = () => ("1.4.0-rc.0")
})();
// webpack/runtime/rspack_unique_id
(() => {
__webpack_require__.ruid = "bundler=rspack@1.4.0-rc.0";

})();
/************************************************************************/
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {

// UNUSED EXPORTS: default

;// CONCATENATED MODULE: external "node:http"
const external_node_http_namespaceObject = require("node:http");
;// CONCATENATED MODULE: ./src/entry.node.ts

/* ESM default export */ const entry_node = ((/* unused pure expression or super */ null && ({
    packs: {
        enable: true
    },
    // 本地执行 dev 和 build 时会使用
    async devApp (esmx) {
        // 这里应使用动态模块。生产依赖不存在。
        return Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 454)).then((m)=>m.createRspackHtmlApp(esmx, {
                minimize: false,
                config (context) {
                // 可以在这里修改 Rspack 编译的配置
                // 自定义你的 Vue、React等框架的打包逻辑
                }
            }));
    },
    async server (esmx) {
        const server = http.createServer((req, res)=>{
            // 静态文件处理
            esmx.middleware(req, res, async ()=>{
                res.setHeader('Content-Type', 'text/html;charset=UTF-8');
                // 传入渲染的参数
                const rc = await esmx.render({
                    importmapMode: 'js',
                    params: {
                        url: req.url
                    }
                });
                // 响应 HTML 内容
                res.end(rc.html);
            });
        });
        // 监听端口
        server.listen(3000, ()=>{
            console.log('http://localhost:3000');
        });
    },
    async postBuild (esmx) {
        const list = [
            '/',
            '/about',
            '/404'
        ];
        for (const url of list){
            const rc = await esmx.render({
                params: {
                    url: url,
                    base: '/ssr-html/'
                }
            });
            esmx.writeSync(esmx.resolvePath('dist/client', url.substring(1), 'index.html'), rc.html);
        }
    },
    modules: {
        exports: [
            'root:src/title/index.ts'
        ]
    }
})));

})();

})()
;
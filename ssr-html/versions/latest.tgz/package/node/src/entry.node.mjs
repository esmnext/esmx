import { createRequire as __WEBPACK_EXTERNAL_createRequire } from "node:module";
// The require scope
var __webpack_require__ = {};

/************************************************************************/
// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
/************************************************************************/

;// CONCATENATED MODULE: external "node:http"
const external_node_http_namespaceObject = __WEBPACK_EXTERNAL_createRequire(import.meta.url)("node:http");
var external_node_http_default = /*#__PURE__*/__webpack_require__.n(external_node_http_namespaceObject);
;// CONCATENATED MODULE: ./src/entry.node.ts

/* ESM default export */ const entry_node = ({
    packs: {
        enable: true
    },
    // 本地执行 dev 和 build 时会使用
    async devApp (esmx) {
        // 这里应使用动态模块。生产依赖不存在。
        return import("@esmx/rspack").then((m)=>m.createRspackHtmlApp(esmx, {
                minimize: false,
                config (context) {
                // 可以在这里修改 Rspack 编译的配置
                // 自定义你的 Vue、React等框架的打包逻辑
                }
            }));
    },
    async server (esmx) {
        const server = external_node_http_default().createServer((req, res)=>{
            // 静态文件处理
            esmx.middleware(req, res, async ()=>{
                res.setHeader('Content-Type', 'text/html;charset=UTF-8');
                // 传入渲染的参数
                const rc = await esmx.render({
                    importmapMode: 'js',
                    params: {
                        url: req.url
                    }
                });
                // 响应 HTML 内容
                res.end(rc.html);
            });
        });
        // 监听端口
        server.listen(3000, ()=>{
            console.log('http://localhost:3000');
        });
    },
    async postBuild (esmx) {
        const list = [
            '/',
            '/about',
            '/404'
        ];
        for (const url of list){
            const rc = await esmx.render({
                params: {
                    url: url,
                    base: '/ssr-html/'
                }
            });
            esmx.writeSync(esmx.resolvePath('dist/client', url.substring(1), 'index.html'), rc.html);
        }
    },
    modules: {
        exports: [
            'root:src/title/index.ts'
        ]
    }
});

export { entry_node as default };

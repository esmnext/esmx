import.meta.chunkName = import.meta.chunkName ?? "ssr-html@src/views/about.ts";
export const __webpack_ids__ = ["473"];
export const __webpack_modules__ = {
545: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  b: () => (/* binding */ layout)
});

;// CONCATENATED MODULE: ./src/components/layout.css

;// CONCATENATED MODULE: ./src/components/layout.ts

function layout(slot) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var _options_base = options.base, base = _options_base === void 0 ? '/' : _options_base;
    // 判断链接是否激活
    var isActive = function(path) {
        // 对于空路径的特殊处理
        if (!path) {
            return '';
        }
        // 如果 options.url 不存在，返回空字符串
        if (!options.url) {
            return '';
        }
        // 从 URL 中移除查询参数
        var urlWithoutQuery = options.url.split('?')[0];
        var pathWithoutQuery = path.startsWith('/') ? path : '/' + path;
        // 对于首页的特殊处理
        if (pathWithoutQuery === '/' && urlWithoutQuery === '/') {
            return 'active';
        }
        return urlWithoutQuery === pathWithoutQuery ? 'active' : '';
    };
    // 处理相对路径
    var resolvePath = function(path) {
        if (path.startsWith('http')) return path;
        return base + (path.startsWith('/') ? path.slice(1) : path);
    };
    return '\n<div class="layout">\n    <header class="header">\n        <div class="container">\n            <h1><img src="https://www.esmnext.com/logo.svg" alt="Esmx Logo" width="48" height="48"></h1>\n            <nav class="nav">\n                <a href="'.concat(resolvePath('/'), ' " class="').concat(isActive('/'), '">\u9996\u9875</a>\n                <a href="').concat(resolvePath('about'), '" class="').concat(isActive('/about'), '">\u5173\u4E8E\u6211\u4EEC</a>\n                <a href="https://github.com/esmnext/esmx/tree/master/examples/ssr-html" target="_blank">\u793A\u4F8B\u4EE3\u7801</a>\n            </nav>\n        </div>\n    </header>\n    <main class="main">\n        <div class="container">\n            ').concat(slot, "\n        </div>\n    </main>\n</div>\n");
}


}),
286: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.d(__webpack_exports__, {
  T: () => (Page)
});
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
var Page = /*#__PURE__*/ function() {
    "use strict";
    function Page() {
        _class_call_check(this, Page);
        _define_property(this, "importMetaSet", new Set());
        _define_property(this, "_props", null);
        _define_property(this, "title", '');
        /**
     * 自定义页面状态
     */ _define_property(this, "state", {});
    }
    _create_class(Page, [
        {
            key: "props",
            get: function get() {
                if (this._props === null) {
                    throw new Error("props is null");
                }
                return this._props;
            },
            set: function set(props) {
                this._props = props;
            }
        },
        {
            key: "render",
            value: /**
     * 服务端渲染生成的 HTML
     */ function render() {
                return "";
            }
        },
        {
            key: "onCreated",
            value: /**
     * 组件已经创建完成，props 和 state 已经准备就绪
     */ function onCreated() {}
        },
        {
            key: "onClient",
            value: /**
     * 客户端执行
     */ function onClient() {}
        },
        {
            key: "onServer",
            value: /**
     * 服务端执行
     */ function onServer() {
                var _this = this;
                return _async_to_generator(function() {
                    return _ts_generator(this, function(_state) {
                        _this.importMetaSet.add(import.meta);
                        return [
                            2
                        ];
                    });
                })();
            }
        }
    ]);
    return Page;
}();


}),
896: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (Home)
});
/* ESM import */var ssr_html_src_components_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(545);
/* ESM import */var ssr_html_src_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(286);
/* ESM import */var _title__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(360);
function _assert_this_initialized(self) {
    if (self === void 0) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _call_super(_this, derived, args) {
    derived = _get_prototype_of(derived);
    return _possible_constructor_return(_this, _is_native_reflect_construct() ? Reflect.construct(derived, args || [], _get_prototype_of(_this).constructor) : derived.apply(_this, args));
}
function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _get(target, property, receiver) {
    if (typeof Reflect !== "undefined" && Reflect.get) {
        _get = Reflect.get;
    } else {
        _get = function get(target, property, receiver) {
            var base = _super_prop_base(target, property);
            if (!base) return;
            var desc = Object.getOwnPropertyDescriptor(base, property);
            if (desc.get) {
                return desc.get.call(receiver || target);
            }
            return desc.value;
        };
    }
    return _get(target, property, receiver || target);
}
function _get_prototype_of(o) {
    _get_prototype_of = Object.setPrototypeOf ? Object.getPrototypeOf : function getPrototypeOf(o) {
        return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _get_prototype_of(o);
}
function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
        constructor: {
            value: subClass,
            writable: true,
            configurable: true
        }
    });
    if (superClass) _set_prototype_of(subClass, superClass);
}
function _possible_constructor_return(self, call) {
    if (call && (_type_of(call) === "object" || typeof call === "function")) {
        return call;
    }
    return _assert_this_initialized(self);
}
function _set_prototype_of(o, p) {
    _set_prototype_of = Object.setPrototypeOf || function setPrototypeOf(o, p) {
        o.__proto__ = p;
        return o;
    };
    return _set_prototype_of(o, p);
}
function _super_prop_base(object, property) {
    while(!Object.prototype.hasOwnProperty.call(object, property)){
        object = _get_prototype_of(object);
        if (object === null) break;
    }
    return object;
}
function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function _is_native_reflect_construct() {
    try {
        var result = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (_) {}
    return (_is_native_reflect_construct = function() {
        return !!result;
    })();
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}



var Home = /*#__PURE__*/ function(Page) {
    "use strict";
    _inherits(Home, Page);
    function Home() {
        _class_call_check(this, Home);
        var _this;
        _this = _call_super(this, Home, arguments), _define_property(_this, "state", {
            time: ''
        }), _define_property(_this, "title", _title__WEBPACK_IMPORTED_MODULE_1__.title.about);
        return _this;
    }
    _create_class(Home, [
        {
            key: "render",
            value: function render() {
                var _this_props = this.props, url = _this_props.url, base = _this_props.base;
                return (0,ssr_html_src_components_layout__WEBPACK_IMPORTED_MODULE_0__/* .layout */.b)('<div class="about-page">\n                <section class="about-hero">\n                    <h2>\u5173\u4E8E Esmx</h2>\n                    <p>\u73B0\u4EE3\u5316\u7684\u5FAE\u524D\u7AEF\u6A21\u5757\u5171\u4EAB\u89E3\u51B3\u65B9\u6848</p>\n                </section>\n                \n                <section class="feature-grid">\n                    <div class="feature-card">\n                        <div class="icon">\u26A1\uFE0F</div>\n                        <div class="content">\n                            <h3>\u6781\u901F\u6784\u5EFA</h3>\n                            <p>\u57FA\u4E8E Rust \u5F00\u53D1\u7684 Rspack \u6784\u5EFA\u5F15\u64CE\uFF0C\u63D0\u4F9B\u6BD4\u4F20\u7EDF\u5DE5\u5177\u5FEB 10-100 \u500D\u7684\u6784\u5EFA\u6027\u80FD\u3002</p>\n                        </div>\n                    </div>\n\n                    <div class="feature-card">\n                        <div class="icon">\uD83D\uDD04</div>\n                        <div class="content">\n                            <h3>\u6A21\u5757\u5171\u4EAB</h3>\n                            <p>\u521B\u65B0\u7684 Module Link \u6280\u672F\uFF0C\u5B9E\u73B0\u591A\u4E2A\u5FAE\u524D\u7AEF\u5E94\u7528\u95F4\u65E0\u7F1D\u5171\u4EAB\u548C\u6309\u9700\u52A0\u8F7D\u6A21\u5757\uFF0C\u964D\u4F4E\u91CD\u590D\u4F9D\u8D56\u3002</p>\n                        </div>\n                    </div>\n\n                    <div class="feature-card">\n                        <div class="icon">\uD83D\uDE80</div>\n                        <div class="content">\n                            <h3>\u6027\u80FD\u4F18\u5316</h3>\n                            <p>\u57FA\u4E8E\u5185\u5BB9\u54C8\u5E0C\u7684\u667A\u80FD\u7F13\u5B58\u7B56\u7565\uFF0C\u914D\u5408 HTTP/3 \u548C ESM\uFF0C\u663E\u8457\u63D0\u5347\u5E94\u7528\u52A0\u8F7D\u6027\u80FD\u3002</p>\n                        </div>\n                    </div>\n\n                    <div class="feature-card">\n                        <div class="icon">\uD83D\uDEE0\uFE0F</div>\n                        <div class="content">\n                            <h3>\u7B80\u5355\u6613\u7528</h3>\n                            <p>\u96F6\u914D\u7F6E\u7684 importmap \u6A21\u5757\u6620\u5C04\uFF0C\u5F00\u7BB1\u5373\u7528\u7684\u6784\u5EFA\u4F18\u5316\uFF0C\u8BA9\u5F00\u53D1\u8005\u4E13\u6CE8\u4E8E\u4E1A\u52A1\u903B\u8F91\u3002</p>\n                        </div>\n                    </div>\n                </section>\n\n                <section class="about-footer">\n                    <div class="update-info">\n                        <span>\u6700\u540E\u66F4\u65B0\uFF1A'.concat(new Date(this.state.time).toLocaleString('zh-CN', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                }), "</span>\n                    </div>\n                </section>\n            </div>"), {
                    url: url,
                    base: base
                });
            }
        },
        {
            key: "onServer",
            value: /**
     * 模拟服务端请求数据
     */ function onServer() {
                var _this = this;
                var _this1 = this, _superprop_get_onServer = function() {
                    return _get(_get_prototype_of(Home.prototype), "onServer", _this);
                };
                return _async_to_generator(function() {
                    return _ts_generator(this, function(_state) {
                        _this1.importMetaSet.add(import.meta);
                        _superprop_get_onServer().call(_this1);
                        _this1.state.time = new Date().toISOString();
                        return [
                            2
                        ];
                    });
                })();
            }
        }
    ]);
    return Home;
}(ssr_html_src_page__WEBPACK_IMPORTED_MODULE_2__/* .Page */.T);



}),

};

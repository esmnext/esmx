import.meta.chunkName = import.meta.chunkName ?? "ssr-html@src/title/index.ts";

;// CONCATENATED MODULE: ./src/title/index.ts
const title = {
    home: 'Home',
    about: 'About',
    notFound: 'Not found'
};

export { title };

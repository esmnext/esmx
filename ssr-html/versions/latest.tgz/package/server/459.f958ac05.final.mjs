import.meta.chunkName = import.meta.chunkName ?? "ssr-html@src/views/home.ts";
export const __webpack_ids__ = ["459"];
export const __webpack_modules__ = {
545: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  b: () => (/* binding */ layout)
});

;// CONCATENATED MODULE: ./src/components/layout.css

;// CONCATENATED MODULE: ./src/components/layout.ts

function layout(slot) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var _options_base = options.base, base = _options_base === void 0 ? '/' : _options_base;
    // 判断链接是否激活
    var isActive = function(path) {
        // 对于空路径的特殊处理
        if (!path) {
            return '';
        }
        // 如果 options.url 不存在，返回空字符串
        if (!options.url) {
            return '';
        }
        // 从 URL 中移除查询参数
        var urlWithoutQuery = options.url.split('?')[0];
        var pathWithoutQuery = path.startsWith('/') ? path : '/' + path;
        // 对于首页的特殊处理
        if (pathWithoutQuery === '/' && urlWithoutQuery === '/') {
            return 'active';
        }
        return urlWithoutQuery === pathWithoutQuery ? 'active' : '';
    };
    // 处理相对路径
    var resolvePath = function(path) {
        if (path.startsWith('http')) return path;
        return base + (path.startsWith('/') ? path.slice(1) : path);
    };
    return '\n<div class="layout">\n    <header class="header">\n        <div class="container">\n            <h1><img src="https://www.esmnext.com/logo.svg" alt="Esmx Logo" width="48" height="48"></h1>\n            <nav class="nav">\n                <a href="'.concat(resolvePath('/'), ' " class="').concat(isActive('/'), '">\u9996\u9875</a>\n                <a href="').concat(resolvePath('about'), '" class="').concat(isActive('/about'), '">\u5173\u4E8E\u6211\u4EEC</a>\n                <a href="https://github.com/esmnext/esmx/tree/master/examples/ssr-html" target="_blank">\u793A\u4F8B\u4EE3\u7801</a>\n            </nav>\n        </div>\n    </header>\n    <main class="main">\n        <div class="container">\n            ').concat(slot, "\n        </div>\n    </main>\n</div>\n");
}


}),
286: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.d(__webpack_exports__, {
  T: () => (Page)
});
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
var Page = /*#__PURE__*/ function() {
    "use strict";
    function Page() {
        _class_call_check(this, Page);
        _define_property(this, "importMetaSet", new Set());
        _define_property(this, "_props", null);
        _define_property(this, "title", '');
        /**
     * 自定义页面状态
     */ _define_property(this, "state", {});
    }
    _create_class(Page, [
        {
            key: "props",
            get: function get() {
                if (this._props === null) {
                    throw new Error("props is null");
                }
                return this._props;
            },
            set: function set(props) {
                this._props = props;
            }
        },
        {
            key: "render",
            value: /**
     * 服务端渲染生成的 HTML
     */ function render() {
                return "";
            }
        },
        {
            key: "onCreated",
            value: /**
     * 组件已经创建完成，props 和 state 已经准备就绪
     */ function onCreated() {}
        },
        {
            key: "onClient",
            value: /**
     * 客户端执行
     */ function onClient() {}
        },
        {
            key: "onServer",
            value: /**
     * 服务端执行
     */ function onServer() {
                return _async_to_generator(function() {
                    return _ts_generator(this, function(_state) {
                        this.importMetaSet.add(import.meta);
                        return [
                            2
                        ];
                    });
                }).call(this);
            }
        }
    ]);
    return Page;
}();


}),
40: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home_Home)
});

// EXTERNAL MODULE: ./src/components/layout.ts + 1 modules
var layout = __webpack_require__(545);
;// CONCATENATED MODULE: ./src/images/cat.jpeg
const cat_namespaceObject = __webpack_require__.p + "images/cat.ed79ef6b.final.jpeg";
;// CONCATENATED MODULE: ./src/images/logo.svg
const logo_namespaceObject = __webpack_require__.p + "images/logo.3923d727.final.svg";
;// CONCATENATED MODULE: ./src/images/running-dog.gif
const running_dog_namespaceObject = __webpack_require__.p + "images/running-dog.76197e20.final.gif";
;// CONCATENATED MODULE: ./src/images/starry.jpg
const starry_namespaceObject = __webpack_require__.p + "images/starry.d914a632.final.jpg";
;// CONCATENATED MODULE: ./src/images/sun.png
const sun_namespaceObject = __webpack_require__.p + "images/sun.429a7bc5.final.png";
;// CONCATENATED MODULE: ./src/images/index.ts







// EXTERNAL MODULE: ./src/page.ts
var page = __webpack_require__(286);
// EXTERNAL MODULE: external "ssr-html/src/title/index"
var index_ = __webpack_require__(360);
;// CONCATENATED MODULE: ./src/views/home.ts
function _assert_this_initialized(self) {
    if (self === void 0) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _call_super(_this, derived, args) {
    derived = _get_prototype_of(derived);
    return _possible_constructor_return(_this, _is_native_reflect_construct() ? Reflect.construct(derived, args || [], _get_prototype_of(_this).constructor) : derived.apply(_this, args));
}
function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _get(target, property, receiver) {
    if (typeof Reflect !== "undefined" && Reflect.get) {
        _get = Reflect.get;
    } else {
        _get = function get(target, property, receiver) {
            var base = _super_prop_base(target, property);
            if (!base) return;
            var desc = Object.getOwnPropertyDescriptor(base, property);
            if (desc.get) {
                return desc.get.call(receiver || target);
            }
            return desc.value;
        };
    }
    return _get(target, property, receiver || target);
}
function _get_prototype_of(o) {
    _get_prototype_of = Object.setPrototypeOf ? Object.getPrototypeOf : function getPrototypeOf(o) {
        return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _get_prototype_of(o);
}
function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
        constructor: {
            value: subClass,
            writable: true,
            configurable: true
        }
    });
    if (superClass) _set_prototype_of(subClass, superClass);
}
function _instanceof(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
function _possible_constructor_return(self, call) {
    if (call && (_type_of(call) === "object" || typeof call === "function")) {
        return call;
    }
    return _assert_this_initialized(self);
}
function _set_prototype_of(o, p) {
    _set_prototype_of = Object.setPrototypeOf || function setPrototypeOf(o, p) {
        o.__proto__ = p;
        return o;
    };
    return _set_prototype_of(o, p);
}
function _super_prop_base(object, property) {
    while(!Object.prototype.hasOwnProperty.call(object, property)){
        object = _get_prototype_of(object);
        if (object === null) break;
    }
    return object;
}
function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function _is_native_reflect_construct() {
    try {
        var result = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (_) {}
    return (_is_native_reflect_construct = function() {
        return !!result;
    })();
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}




var home_Home = /*#__PURE__*/ function(Page) {
    "use strict";
    _inherits(Home, Page);
    function Home() {
        _class_call_check(this, Home);
        var _this;
        _this = _call_super(this, Home, arguments), _define_property(_this, "state", {
            count: 0,
            time: ''
        }), _define_property(_this, "title", index_.title.home);
        return _this;
    }
    _create_class(Home, [
        {
            key: "render",
            value: function render() {
                var _this_props = this.props, url = _this_props.url, base = _this_props.base;
                var count = this.state.count;
                return (0,layout/* .layout */.b)('\n        <section>\n            <h2>\u8BA1\u6570\u5668</h2>\n            <div class="content-area counter">\n                <div id="count" class="counter-value">'.concat(count, '</div>\n            </div>\n        </section>\n\n        <section>\n            <h2>\u8BF7\u6C42\u5730\u5740</h2>\n            <div class="content-area url-section">\n                <pre>').concat(url, '</pre>\n            </div>\n        </section>\n\n        <section>\n            <h2>\u56FE\u7247\u5C55\u793A</h2>\n            <ul class="image-grid">\n                <li>\n                    <div class="image-wrapper">\n                        <img src="').concat(logo_namespaceObject, '" alt="SVG\u793A\u4F8B" width="200" height="200">\n                    </div>\n                    <div class="image-info">\n                        <h3>SVG \u793A\u4F8B</h3>\n                        <p>\u7C7B\u578B\uFF1ASVG</p>\n                        <p>\u5C3A\u5BF8\uFF1A200 x 200</p>\n                    </div>\n                </li>\n                <li>\n                    <div class="image-wrapper">\n                        <img src="').concat(starry_namespaceObject, '" alt="JPG\u793A\u4F8B" width="1024" height="768">\n                    </div>\n                    <div class="image-info">\n                        <h3>JPG \u793A\u4F8B</h3>\n                        <p>\u7C7B\u578B\uFF1AJPG</p>\n                        <p>\u5C3A\u5BF8\uFF1A1024 x 768</p>\n                    </div>\n                </li>\n                <li>\n                    <div class="image-wrapper">\n                        <img src="').concat(cat_namespaceObject, '" alt="\u732B\u54AA\u56FE\u7247" width="769" height="225">\n                    </div>\n                    <div class="image-info">\n                        <h3>\u732B\u54AA\u56FE\u7247</h3>\n                        <p>\u7C7B\u578B\uFF1APNG</p>\n                        <p>\u5C3A\u5BF8\uFF1A769 x 225</p>\n                    </div>\n                </li>\n                <li>\n                    <div class="image-wrapper">\n                        <img src="').concat(running_dog_namespaceObject, '" alt="\u75AF\u72C2\u7F16\u7801" width="480" height="297">\n                    </div>\n                    <div class="image-info">\n                        <h3>\u75AF\u72C2\u7F16\u7801</h3>\n                        <p>\u7C7B\u578B\uFF1AGIF</p>\n                        <p>\u5C3A\u5BF8\uFF1A480 x 297</p>\n                    </div>\n                </li>\n                <li>\n                    <div class="image-wrapper">\n                        <img src="').concat(sun_namespaceObject, '" alt="\u592A\u9633\u56FE\u6807" width="351" height="300">\n                    </div>\n                    <div class="image-info">\n                        <h3>\u592A\u9633\u56FE\u6807</h3>\n                        <p>\u7C7B\u578B\uFF1ASVG</p>\n                        <p>\u5C3A\u5BF8\uFF1A351 x 300</p>\n                    </div>\n                </li>\n            </ul>\n        </section>\n\n        <section class="update-section">\n            <div class="update-info">\n                <span>\u6700\u540E\u66F4\u65B0\uFF1A').concat(new Date(this.state.time).toLocaleString('zh-CN', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                }), "</span>\n            </div>\n        </section>\n"), {
                    url: url,
                    base: base
                });
            }
        },
        {
            key: "onClient",
            value: function onClient() {
                var _this = this;
                setInterval(function() {
                    _this.state.count++;
                    var countEl = document.querySelector('#count');
                    if (_instanceof(countEl, HTMLDivElement)) {
                        countEl.innerText = String(_this.state.count);
                    }
                }, 1000);
            }
        },
        {
            key: "onServer",
            value: /**
     * 模拟服务端请求数据
     */ function onServer() {
                var _this = this;
                var _this1 = this, _superprop_get_onServer = function() {
                    return _get(_get_prototype_of(Home.prototype), "onServer", _this);
                };
                return _async_to_generator(function() {
                    return _ts_generator(this, function(_state) {
                        this.importMetaSet.add(import.meta);
                        _superprop_get_onServer().call(_this1);
                        this.state.count = 1;
                        this.state.time = new Date().toISOString();
                        return [
                            2
                        ];
                    });
                }).call(this);
            }
        }
    ]);
    return Home;
}(page/* .Page */.T);



}),

};

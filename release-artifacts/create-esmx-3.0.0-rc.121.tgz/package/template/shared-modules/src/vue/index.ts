export { version } from 'vue';

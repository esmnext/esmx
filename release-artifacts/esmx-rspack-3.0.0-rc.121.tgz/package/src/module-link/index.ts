import type { RspackChain } from 'rspack-chain';
import { applyChainConfig1 } from './config1';
import { ManifestPlugin } from './manifest-plugin';
import { parseOptions } from './parse';
import type { ModuleLinkPluginOptions } from './types';

export function initModuleLink(
    chain: RspackChain,
    options: ModuleLinkPluginOptions,
    isProduction = false
): void {
    const opts = parseOptions(options);
    applyChainConfig1(chain, opts);

    chain
        .plugin('module-link-manifest')
        .use(ManifestPlugin, [opts, isProduction]);
}

export type { ModuleLinkPluginOptions } from './types';
